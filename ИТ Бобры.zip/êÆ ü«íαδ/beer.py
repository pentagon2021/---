import face_recognition
from fastapi import FastAPI, File, UploadFile
from fastapi .middleware.cors import  CORSMiddleware


app = FastAPI()

origins = [
    "*"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

import shutil

@app.get("/")
def read_root():
    return {"Hello": "World"}



@app.post("/recognize/")
def create_file(file: UploadFile = File(...)):
	with open("samples/test.jpeg", "wb") as buffer:
	    shutil.copyfileobj(file.file, buffer)

	unknown_image = face_recognition.load_image_file("samples/test.jpeg")
	
	try:
		unknown_encoding = face_recognition.face_encodings(unknown_image)[0]
		result = start_comparing(unknown_encoding)	
	except Exception as e:
		result = "Тут нет лица"
	else:
		pass
	finally:
		pass


	return {"filename": file.filename, "result": result}					

